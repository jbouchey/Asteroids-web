from constants import *
import pygame


# Base class for game objects
class CircleShape(pygame.sprite.Sprite):
    containers: tuple[pygame.sprite.Group, ...]

    def __init__(self, x: float, y: float, radius: float) -> None:
        # we will be using this later
        if hasattr(self, "containers"):
            super().__init__(*self.containers)
        else:
            super().__init__()

        self.position: pygame.Vector2 = pygame.Vector2(x, y)
        self.velocity = pygame.Vector2(0, 0)
        self.radius = radius

    def collides_with(self, other) -> bool:
        distance = self.position.distance_to(other.position)
        return distance <= self.radius + other.radius

    def draw(self, screen: pygame.Surface) -> None:
        pygame.draw.polygon(screen, "white",self.triangle(),width=LINE_WIDTH)

    def update(self, dt: float) -> None:

        pass

    def wrap_position(self) -> None:
            if self.position.x > SCREEN_WIDTH:
                self.position.x = 0
            if self.position.x < 0:
                self.position.x = SCREEN_WIDTH
            if self.position.y > SCREEN_HEIGHT:
                self.position.y = 0
            if self.position.y < 0:
                self.position.y = SCREEN_HEIGHT
